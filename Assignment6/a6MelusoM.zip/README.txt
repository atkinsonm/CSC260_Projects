README.TXT

Welcome to the Matrix program! This program wil demonstrate basic functionality of overloaded methods
using matrices. To input from the keyboard, type '0' when prompted. To input from a file, make sure that
the file is in the same directory as the program, type '1' when prompted, and the name of the file when prompted.
Please only include one matrix per file, in the following format:

number_rows number_columns
data data data data

e.x. 
2 3
4 7 9
5 1 2

The program will then run a series of tests of functionality of the program, and output to the screen.